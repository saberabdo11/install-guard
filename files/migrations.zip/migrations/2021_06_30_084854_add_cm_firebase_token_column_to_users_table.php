<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Twilio\Rest\Accounts\V1;

class AddCmFirebaseTokenColumnToUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            if(!Schema::hasColumn('users', 'cm_firebase_token'))  {
                $table->string('cm_firebase_token')->nullable();
            } else {
                $table->string('cm_firebase_token')->nullable()->change();
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            if(Schema::hasColumn('users', 'cm_firebase_token')) {
                $table->dropColumn('cm_firebase_token');
            }
        });
    }
}
